package apbdoo.laboratorul12.repositories;

import apbdoo.laboratorul12.domain.Categorie;
import org.springframework.data.repository.CrudRepository;

public interface CategorieRepository extends CrudRepository<Categorie, Long> {
    Categorie findByDenumire(String denumire);
}
