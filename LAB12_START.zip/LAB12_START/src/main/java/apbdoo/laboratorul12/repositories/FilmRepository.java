package apbdoo.laboratorul12.repositories;

import apbdoo.laboratorul12.domain.Film;
import org.springframework.data.repository.CrudRepository;

public interface FilmRepository extends CrudRepository<Film, Long> {
}
