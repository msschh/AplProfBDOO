package apbdoo.laboratorul12.repositories;

import apbdoo.laboratorul12.domain.InfoActor;
import org.springframework.data.repository.CrudRepository;

public interface InfoActorRepository extends CrudRepository<InfoActor, Long> {
    InfoActor findByNume(String nume);
}
