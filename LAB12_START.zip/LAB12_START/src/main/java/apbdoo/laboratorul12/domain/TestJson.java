package apbdoo.laboratorul12.domain;

import lombok.Data;

@Data
public class TestJson {
    long userId;
    long id;
    String title;
    Boolean completed;
}
