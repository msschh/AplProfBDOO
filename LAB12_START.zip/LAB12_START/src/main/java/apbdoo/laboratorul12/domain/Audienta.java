package apbdoo.laboratorul12.domain;

public enum Audienta {
    AG, AP12, N15
}
