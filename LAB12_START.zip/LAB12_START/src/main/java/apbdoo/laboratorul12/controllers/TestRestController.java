package apbdoo.laboratorul12.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class TestRestController {
    @GetMapping("hello")
    public String helloWord(){
        return "Hello Word!";
    }
}
