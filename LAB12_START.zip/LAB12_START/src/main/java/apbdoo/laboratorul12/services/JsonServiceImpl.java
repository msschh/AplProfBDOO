package apbdoo.laboratorul12.services;

import apbdoo.laboratorul12.domain.TestJson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class JsonServiceImpl implements JsonService{
    @Autowired
    RestTemplate restTemplate;


    @Override
    public TestJson getTestJson() {
        return restTemplate.getForObject(
                "https://jsonplaceholder.typicode.com/todos/1", TestJson.class);
    }
}
