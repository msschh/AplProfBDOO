package apbdoo.laboratorul12.services;


import apbdoo.laboratorul12.domain.TestJson;

public interface JsonService {
    TestJson getTestJson();
}
