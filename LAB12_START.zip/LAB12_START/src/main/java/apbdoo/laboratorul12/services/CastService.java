package apbdoo.laboratorul12.services;

import apbdoo.laboratorul12.domain.Cast;

public interface CastService {
    Cast findByFilmIdAndCastId(Long filmId, Long castId);
    Cast saveCast(Cast cast);
    void deleteById(Long filmId, Long castId);
}
