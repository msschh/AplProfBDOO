package apbdoo.laboratorul12.services;

import apbdoo.laboratorul12.commands.CategorieCommand;

public interface CategorieService {
    CategorieCommand saveCategorieCommand(CategorieCommand
                                                  categorieCommand);
}