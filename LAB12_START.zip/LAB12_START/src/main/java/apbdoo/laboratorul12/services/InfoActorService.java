package apbdoo.laboratorul12.services;

import apbdoo.laboratorul12.domain.InfoActor;

import java.util.Set;

public interface InfoActorService {
    Set<InfoActor> listAllActors();
}
