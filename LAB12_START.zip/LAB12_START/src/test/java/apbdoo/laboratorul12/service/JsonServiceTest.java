package apbdoo.laboratorul12.service;

import apbdoo.laboratorul12.services.JsonService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
@Slf4j
public class JsonServiceTest {
    @Autowired
    JsonService jsonService;

    @Test
    public void testServiceJson(){

        log.info(jsonService.getTestJson().toString());
    }
}
