import apbdoo.laboratorul12.domain.Film;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import java.io.IOException;

@Slf4j
public class JsonTest {
    public static final String jsonObject = "{\"titlu\":\"titluTest\"," +
            "\"cast\":[{\"rol\":\"rolTest\"}]," +
            "\"regizor\":\"regTest\"}";


    @Test
    public void MapJson() throws IOException {

        ObjectMapper objectMapper = new ObjectMapper();
        log.info(jsonObject);
        Film result = objectMapper.readValue(jsonObject, Film.class);
        log.info(result.toString());

        String jsonFilm = "";
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
        jsonFilm = objectMapper.writeValueAsString(result);
        log.info(jsonFilm);
    }
}
