package com.apbdoo.subscription;

import com.apbdoo.subscription.model.SubscriptionPrice;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

//@FeignClient(name = "subscription", url = "localhost:8082")
@FeignClient(name = "subscription")
@RibbonClient(name = "subscription")
public interface SubscriptionServiceProxy {
    @GetMapping("/subscription/coach/{coach}/sport/{sport}")
    SubscriptionPrice findByCoachAndSport(@PathVariable String coach,
                                          @PathVariable String sport);
}
