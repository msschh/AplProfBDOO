package com.apbdoo.subscription.controller;

import com.apbdoo.subscription.SubscriptionServiceProxy;
import com.apbdoo.subscription.model.SubscriptionPrice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@RestController
public class SubscriptionController {
    @Autowired
    SubscriptionServiceProxy subscriptionServiceProxy;

    @GetMapping("/subscription/coach/{coach}/sport/{sport}/months/{months}")
    SubscriptionPrice calculateByCoachAndSport(@PathVariable String coach,
                                          @PathVariable String sport,
                                          @PathVariable BigDecimal months){
        SubscriptionPrice subscriptionPrice = new SubscriptionPrice();
        subscriptionPrice.setCoach(coach);
        subscriptionPrice.setMonths(months);
        subscriptionPrice.setSport(sport);


        Map<String, String> mapUri = new HashMap<String, String>();
        mapUri.put("coach",coach);
        mapUri.put("sport",sport);
        ResponseEntity<SubscriptionPrice> responseEntity = new RestTemplate().getForEntity("http://localhost:8082/subscription/coach/{coach}/sport/{sport}",SubscriptionPrice.class, mapUri);

        subscriptionPrice.setPrice(responseEntity.getBody().getPrice());
        subscriptionPrice.calculate();
        return subscriptionPrice;

    }

    @GetMapping("/subscriptionfeign/coach/{coach}/sport/{sport}/months/{months}")
    SubscriptionPrice calculateByCoachAndSportFeign(@PathVariable String coach,
                                               @PathVariable String sport,
                                               @PathVariable BigDecimal months){
        SubscriptionPrice subscriptionPrice;

        subscriptionPrice = subscriptionServiceProxy.findByCoachAndSport(coach, sport);

        subscriptionPrice.setMonths(months);
        subscriptionPrice.calculate();
        return subscriptionPrice;

    }


}
