package com.apbdoo.subscription.model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter

public class Subscription {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name="coach")
    private String coach;

    @Column(name="sport")
    private String sport;

    @Column(name="price")
    private int price;

    @Column(name = "instance_id", nullable = true)
    private Integer instanceId;
}
