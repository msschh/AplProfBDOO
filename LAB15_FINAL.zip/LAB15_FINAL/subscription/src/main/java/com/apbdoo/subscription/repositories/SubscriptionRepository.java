package com.apbdoo.subscription.repositories;

import com.apbdoo.subscription.model.Subscription;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

public interface SubscriptionRepository extends CrudRepository<Subscription, Long> {
    Subscription findByCoachAndSport(String coach, String sport);
}
