package com.apbdoo.subscription.services;

import com.apbdoo.subscription.model.Subscription;
import com.apbdoo.subscription.repositories.SubscriptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SubscriptionServiceImpl implements SubscriptionService {

    @Autowired
    SubscriptionRepository subscriptionRepository;

    @Override
    public Subscription findByCoachAndSport(String coach, String sport) {
        Subscription subscription = subscriptionRepository.findByCoachAndSport(coach,sport);
        return subscription;
    }
}
