package com.apbdoo.subscription.controller;

import com.apbdoo.subscription.model.Subscription;
import com.apbdoo.subscription.services.SubscriptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SubscriptionController {
    @Autowired
    SubscriptionService subscriptionService;

    @Autowired
    Environment environment;

    @GetMapping("/subscription/coach/{coach}/sport/{sport}")
    Subscription findByCoachAndSport(@PathVariable String coach,
                                     @PathVariable String sport){
        Subscription subscription = subscriptionService.findByCoachAndSport(coach, sport);
        subscription.setInstanceId(Integer.parseInt(environment.getProperty("instance.id")));



        return subscription;
    }


}
