package com.apbdoo.lab7.model;
import lombok.Data;

@Data
public class Hello {
    private Long id;
    private String name;
}
