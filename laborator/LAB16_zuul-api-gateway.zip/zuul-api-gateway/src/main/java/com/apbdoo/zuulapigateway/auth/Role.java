package com.apbdoo.zuulapigateway.auth;

import lombok.Data;

import java.util.Objects;

@Data
public class Role {
    private Integer id;
    private String  role;

}
