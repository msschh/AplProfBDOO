package com.apbdoo.zuulapigateway.auth;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import java.util.Set;


@Document
@Data
public class User {
    @Id
    private String id;
    @Email(message = "enter valid email")
    @NotEmpty(message = "provide email")
    private String email;

    @NotEmpty(message = "provide password")
    private String password;

    @NotEmpty(message = "provide name")
    private String name;

    private Integer active=1;
    private boolean isLocked =false;
    private boolean isExpired=false;
    private boolean isEnabled=true;

    private Set<Role> role;

}
