package com.apbdoo.zuulapigateway.service;
/*
import com.apbdoo.zuulapigateway.services.UserService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UserServiceTest {
    public static final String EMAIL = "usertest3@yahoo.com";

    @Autowired
    UserService userService;

    @Test
    public void testUserService(){
        UserDetails userDetails = userService.loadUserByUsername(EMAIL);
        assertEquals(EMAIL, userDetails.getUsername());
    }
}

*/