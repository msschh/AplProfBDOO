package apbdoo.laboratorul9.services;

import apbdoo.laboratorul9.commands.CategorieCommand;

public interface CategorieService {
    CategorieCommand saveCategorieCommand(CategorieCommand
                                                  categorieCommand);
}