package apbdoo.laboratorul9.domain;

public enum Audienta {
    AG, AP12, N15
}
