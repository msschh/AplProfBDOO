package apbdoo.laboratorul9.services;

import apbdoo.laboratorul9.domain.InfoActor;

import java.util.Set;

public interface InfoActorService {
    Set<InfoActor> listAllActors();
}
