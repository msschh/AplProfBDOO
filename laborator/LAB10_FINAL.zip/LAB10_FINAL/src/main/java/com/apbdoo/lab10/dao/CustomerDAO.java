package com.apbdoo.lab10.dao;

import com.apbdoo.lab10.model.Customer;

import java.util.List;



public interface CustomerDAO {
	public List<Customer> getCustomers();
	public void saveCustomer(Customer customer);
}
