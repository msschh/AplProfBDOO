package com.apbdoo.lab10.controllers;

import com.apbdoo.lab10.model.Hello;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class IndexController {
    @GetMapping("/showLogInForm")
    public String showLogInForm(){
        return "login";
    }

    @GetMapping("/showErrorLogIn")
    public String showErrorLogIn(Model model){
        model.addAttribute("errorMessage", "try again ... ");
        return "login";
    }

    @GetMapping("/logout")
    public String logout(){
        return "login";
    }

    @GetMapping("/accessDenied")
    public String acessDenied(){
        return "access-denied";

    }

    @RequestMapping("/")
    public String showIndex(){
        return "home";
    }

    @RequestMapping("/showForm")
    public String showInputForm(Model model){
        model.addAttribute("hello",new Hello());
        return "form-hello";
    }


    @RequestMapping(value="/hello", method = RequestMethod.POST )
    @ResponseBody
    public String showHelloWord(@RequestParam(required = false) String name){

        return "Hello " + name;
    }




    @PostMapping("/greeting")
    public String greetingSubmit(@ModelAttribute Hello hello) {
        return "result";
    }

}
