package com.apbdoo.lab10.service;

import com.apbdoo.lab10.model.Customer;

import java.util.List;

public interface CustomerService {

	public List<Customer> getCustomers();
	public void saveCustomer(Customer customer);
	
}
