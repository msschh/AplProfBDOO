package com.apbdoo.discountservice.controllers;

import com.apbdoo.discountservice.config.PropertiesConfiguration;
import com.apbdoo.discountservice.model.Discount;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
    @Autowired
    private PropertiesConfiguration configuration;

    @GetMapping("/discount")
    public Discount getDiscount(){

        return new Discount(configuration.getMonth(),configuration.getYear());
    }
}
