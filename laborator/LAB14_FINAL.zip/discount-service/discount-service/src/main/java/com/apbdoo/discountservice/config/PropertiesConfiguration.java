package com.apbdoo.discountservice.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("discount-service")
@Getter
@Setter
public class PropertiesConfiguration {
    private int month;
    private int year;
}
