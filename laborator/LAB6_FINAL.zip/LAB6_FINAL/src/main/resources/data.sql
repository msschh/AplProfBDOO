insert into film (titlu) values ('Mary Poppins Returns');
insert into film (titlu) values ('Grinch');
insert into categorie (denumire) values ('animatie');
insert into categorie (denumire) values ('fantasy');
insert into categorie (denumire) values ('comedie');
insert into info_actor(nume, info) values ('Jason Momoa',
    'Joseph Jason Namakaeha Momoa was born on August 1, 1979, in Honolulu, Hawaii. ');
insert into info_actor(nume, info) values ('Amber Heard',
    'Amber Laura Heard was born in Austin, Texas, to Patricia Paige Heard (née Parsons), an internet researcher, and David C. Heard (David Clinton Heard), a contractor.');
insert into info_actor(nume, info) values ('Patrick Wilson','Patrick Joseph Wilson was born in Norfolk, Virginia and raised in St. Petersburg, Florida.');
insert into info_actor(nume, info) values ('Nicole Kidman','Nicole Kidman, known as one of Hollywood s top Australian imports, was actually born in Honolulu.');
