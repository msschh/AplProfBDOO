package apbdoo.laboratorul6.services;

import apbdoo.laboratorul6.domain.InfoActor;

import java.util.Set;

public interface InfoActorService {
    Set<InfoActor> listAllActors();
}
