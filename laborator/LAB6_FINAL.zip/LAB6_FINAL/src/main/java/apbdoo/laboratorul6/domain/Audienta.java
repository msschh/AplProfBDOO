package apbdoo.laboratorul6.domain;

public enum Audienta {
    AG, AP12, N15
}
