package apbdoo.laboratorul6.services;

import apbdoo.laboratorul6.commands.CategorieCommand;

public interface CategorieService {
    CategorieCommand saveCategorieCommand(CategorieCommand
                                                  categorieCommand);
}