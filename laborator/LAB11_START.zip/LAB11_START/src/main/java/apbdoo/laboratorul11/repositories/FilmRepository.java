package apbdoo.laboratorul11.repositories;

import apbdoo.laboratorul11.domain.Film;
import org.springframework.data.repository.CrudRepository;

public interface FilmRepository extends CrudRepository<Film, Long> {
}
