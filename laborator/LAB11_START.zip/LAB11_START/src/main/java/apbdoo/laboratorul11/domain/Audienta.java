package apbdoo.laboratorul11.domain;

public enum Audienta {
    AG, AP12, N15
}
