package apbdoo.laboratorul11.services;

import apbdoo.laboratorul11.commands.CategorieCommand;

public interface CategorieService {
    CategorieCommand saveCategorieCommand(CategorieCommand
                                                  categorieCommand);
}