package apbdoo.laboratorul11.services;

import apbdoo.laboratorul11.domain.InfoActor;

import java.util.Set;

public interface InfoActorService {
    Set<InfoActor> listAllActors();
}
