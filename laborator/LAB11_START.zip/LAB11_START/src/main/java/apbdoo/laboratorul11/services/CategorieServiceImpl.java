package apbdoo.laboratorul11.services;

import apbdoo.laboratorul11.commands.CategorieCommand;
import apbdoo.laboratorul11.converters.CategorieToCommandConverter;
import apbdoo.laboratorul11.converters.CommandToCategorieConverter;
import apbdoo.laboratorul11.domain.Categorie;
import apbdoo.laboratorul11.repositories.CategorieRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@AllArgsConstructor
@Slf4j
@Service
public class CategorieServiceImpl implements CategorieService {
    CategorieRepository categorieRepository;
    CommandToCategorieConverter commandToCategorieConverter;
    CategorieToCommandConverter categorieToCommandConverter;

    @Override
    public CategorieCommand saveCategorieCommand(CategorieCommand categorieCommand){
        Categorie categorie =  commandToCategorieConverter.convert(categorieCommand);
        log.info("saving categrie " + categorie.getDenumire());
        Categorie savedCategorie = categorieRepository.save(categorie);
        return categorieToCommandConverter.convert(savedCategorie);
    }
}
