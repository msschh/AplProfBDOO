package apbdoo.laboratorul11.repositories;

import apbdoo.laboratorul11.domain.InfoActor;
import org.springframework.data.repository.CrudRepository;

public interface InfoActorRepository extends CrudRepository<InfoActor, Long> {
    InfoActor findByNume(String nume);
}
