package com.apbdoo.lab7.dao;

import com.apbdoo.lab7.model.Customer;

import java.util.List;



public interface CustomerDAO {


	public List<Customer> getCustomers();
	
}
