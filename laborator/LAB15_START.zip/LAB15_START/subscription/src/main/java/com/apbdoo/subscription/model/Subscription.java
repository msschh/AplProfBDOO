package com.apbdoo.subscription.model;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
public class Subscription {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name="coach")
    private String coach;

    @Column(name="sport")
    private String sport;

    @Column(name="price")
    private int price;

}
