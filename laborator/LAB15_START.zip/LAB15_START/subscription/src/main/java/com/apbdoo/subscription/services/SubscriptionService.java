package com.apbdoo.subscription.services;

import com.apbdoo.subscription.model.Subscription;

public interface SubscriptionService {
    Subscription findByCoachAndSport(String coach, String sport);
}
