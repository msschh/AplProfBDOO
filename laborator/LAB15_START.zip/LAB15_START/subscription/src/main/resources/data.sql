insert into subscription(coach, sport, price)
 values ('James', 'tennis', 200);
insert into subscription(coach, sport, price)
 values ('Adam', 'swimming', 250);
insert into subscription(coach, sport, price)
 values ('Jhon', 'tennis', 175);
insert into subscription(coach, sport, price)
 values ('Eva', 'swimming', 220);

