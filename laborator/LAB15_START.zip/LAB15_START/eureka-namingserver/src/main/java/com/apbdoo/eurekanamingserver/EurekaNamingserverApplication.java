package com.apbdoo.eurekanamingserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekaNamingserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaNamingserverApplication.class, args);
	}

}
