package com.apbdoo.subscription.controller;

import com.apbdoo.subscription.model.SubscriptionPrice;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;

@RestController
public class SubscriptionController {

    @GetMapping("/subscription/coach/{coach}/sport/{sport}/months/{months}")
    SubscriptionPrice findByCoachAndSport(@PathVariable String coach,
                                          @PathVariable String sport,
                                          @PathVariable BigDecimal months){
        SubscriptionPrice subscriptionPrice = new SubscriptionPrice();
        subscriptionPrice.setCoach(coach);
        subscriptionPrice.setMonths(months);
        subscriptionPrice.setSport(sport);

        return subscriptionPrice;

    }


}
