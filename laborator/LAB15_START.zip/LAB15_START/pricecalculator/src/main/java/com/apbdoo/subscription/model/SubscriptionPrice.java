package com.apbdoo.subscription.model;

import lombok.Data;

import java.math.BigDecimal;


@Data
public class SubscriptionPrice {
    private Long id;
    private String coach;
    private String sport;
    private int price;
    private BigDecimal months;
    private BigDecimal calculatedPrice;

}
