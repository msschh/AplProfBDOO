insert into user(name) values('Jhon');
insert into user(name) values('Mary');
insert into user(name) values('Bob');