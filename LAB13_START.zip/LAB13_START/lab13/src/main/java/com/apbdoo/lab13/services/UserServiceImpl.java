package com.apbdoo.lab13.services;

import com.apbdoo.lab13.model.User;
import com.apbdoo.lab13.repositories.UserRepository;
import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService{
    private UserRepository userRepository;

    UserServiceImpl(UserRepository userRepository){
        this.userRepository = userRepository;
    }

    public List<User> getUsers(){
        List<User> users = new LinkedList<>();
        userRepository.findAll().iterator().forEachRemaining(users::add);
        return users;
    }

    public User getById(Long id){
        Optional<User> userOptional = userRepository.findById(id);
        if (! userOptional.isPresent())
            throw new RuntimeException("User not found!");
        return userOptional.get();
    }
}
