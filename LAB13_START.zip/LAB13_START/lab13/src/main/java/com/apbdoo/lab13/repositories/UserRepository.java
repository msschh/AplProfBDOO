package com.apbdoo.lab13.repositories;

import com.apbdoo.lab13.model.User;
import org.springframework.data.repository.CrudRepository;


public interface UserRepository extends CrudRepository<User, Long> {

}
