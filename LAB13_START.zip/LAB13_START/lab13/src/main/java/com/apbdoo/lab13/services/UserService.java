package com.apbdoo.lab13.services;

import com.apbdoo.lab13.model.User;

import java.util.List;

public interface UserService {
    List<User> getUsers();
    User getById(Long id);
}
